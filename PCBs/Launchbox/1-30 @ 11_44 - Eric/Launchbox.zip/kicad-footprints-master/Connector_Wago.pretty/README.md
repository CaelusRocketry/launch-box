# Connector_Wago.pretty
This library contains footprints for Wago connectors

---

Specialized scripts are used to generate the following connectors:

- 734 vertical and horizontal

Script details:

- author: Poeschl Rene
- script location: https://github.com/pointhi/kicad-footprint-generator/tree/master/scripts/Connector/Connector_Wago/
- used config file: config_KLCv3.0.yaml
- python version: 3.6.2
